package com.example.uts_selsa;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {
    ListView Listview;
    Spinner combo;

    public String Menu_Makanan [] ={"Nasi Goreng Sehat","Nasi Goreng Ayam","Nasi Goreng Telur","Mie Rebus"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Listview =(ListView) findViewById(R.id.ListMakanan);
        combo=(Spinner ) findViewById(R.id.comboMakanan);

        ArrayAdapter adapter = new ArrayAdapter(MainActivity.this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item,Menu_Makanan);
    }
}